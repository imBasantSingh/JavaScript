// how to iterate object 

// create objects 
const userDetails = {
    fisrtName: "Basant" , 
    lastName: "Singh" ,
    age: 33, 
    sex: "Male", 
    "user hobbies": ["GYM", "Travelling", "listening music", "Cricket"] 
}

// for in loop Object.keys 
/*
for(let key in userDetails){
  console.log(`${key} : ${userDetails[key]}`);
}
*/

/*
for(let key in userDetails){
  //console.log(`${key} : ${userDetails[key]}`);
  console.log(key," : ",userDetails[key]);
}
*/

// console.log(typeof (Object.keys(userDetails)));
// const val = Array.isArray((Object.keys(userDetails)));
// console.log(val);

/*
for(let key of Object.keys(userDetails)){
    console.log(userDetails[key]);
}
*/

for(let key of Object.keys(userDetails)){
  console.log(key, " : ", userDetails[key]);
}