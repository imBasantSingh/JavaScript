// spread operator in objects
const obj1 = {
  key1: "value1",
  key2: "value2",
};

const obj2 = {
  key1: "valueUnique",
  key3: "value3",
  key4: "value4",
};

const newObject = { ...obj2, ...obj1, key69: "value69" };
//const newObject2 = { ...["item1", "item2"] };
const newObject2 = { ..."abcdefghijklmnopqrstuvwxyz" };
console.log(newObject);
console.log(newObject2);