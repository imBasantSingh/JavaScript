// difference between dot and bracket notaion
const key = "email";

// create objects 
const userDetails = {
    fisrtName: "Basant" , 
    lastName: "Singh" ,
    age: 33, 
    sex: "Male", 
    "user hobbies": ["GYM", "Travelling", "listening music", "Cricket"] 
}

console.log(userDetails["user hobbies"]);

// Add key value pair to objects
userDetails[key] = "basant.nits@gmail.com";
console.log(userDetails);