// object destructuring
const singer = {
  singerName: "KK",
  famousSong: "Alvida",
  year: 1978,
  anotherFamousSong: "Ankho mein teri",
};

let { singerName, famousSong, ...restDetail } = singer;
    
console.log(singerName);
console.log(restDetail);