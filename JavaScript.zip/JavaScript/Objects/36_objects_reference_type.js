/* 
Arrays are good but not sufficient for real world data 
objects reference type, objects don't have index, objects store key value pairs
*/

// create objects 
const userDetails = {
    fisrtName: "Basant" , 
    lastName: "Singh" ,
    age: 33, 
    sex: "Male", 
    hobbies: ["GYM", "Travelling", "listening music", "Cricket"] 
}

//Print Object in console
console.log(userDetails);

// Access data from objects 
console.log(userDetails["fisrtName"]);
console.log(userDetails.lastName);

// Add key value pair to objects
userDetails.email = "basant.nits@gmail.com";
userDetails["key"] = "Values";

//Print Object in console
console.log(userDetails);