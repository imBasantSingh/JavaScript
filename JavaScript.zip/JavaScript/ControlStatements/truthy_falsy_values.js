// truthy and falsy values 

// falsy values 


// false
// ""
// null 
// undefined
// 0
if(""){
    console.log(true);
    } 
else console.log(false);