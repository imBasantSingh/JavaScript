// while loop example 
let num = 100;
let total = 0; //1 + 2 +3
let i = 0;

while(i<=100){
   total = total + i;
   i++;
}
console.log(total);

// let total = (num*(num+1))/2;
// console.log(total);