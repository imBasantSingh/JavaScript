// intro to for loop 
// print 0 to 9

for(let i = 0;i<=9;i++){
    console.log(i);
}

// console.log("value of i is ",i);