// do while loop


let i = 10;
do{
  console.log(i);
   i++;
}while(i<=9);

console.log("value of i is ", i);