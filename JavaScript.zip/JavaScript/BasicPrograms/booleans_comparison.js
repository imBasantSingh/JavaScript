// booleans & comparison operator
//This data type represents logical entities. Boolean represents one of two values: true or false

/* 
Use == if you want to compare values for equality while allowing for type coercion. 
It's useful when you want loose equality checking.
Use === if you want to compare values for strict equality, including both the values
 and the types. It's recommended for most cases because it helps prevent unexpected type-related issues in your code.
 
In general, it's a good practice to use === for equality comparisons unless you have 
a specific reason to use == and understand its type coercion behavior.
*/

let num1 = 7;
let num2 = "7";

console.log(num1 === num2);
console.log(num1 == num2);

// == vs ===
// console.log(num1 === num2);

// != vs !==

// console.log(num1 !== num2);
