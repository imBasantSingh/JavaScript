"use strict";
// let keyword
// declare variable with let keyword
// If you use a variable without initializing it, it will have an undefined value.
let lastName;
let firstName = "Basant";
firstName = "Kajal";
console.log(firstName);
console.log(lastName);
