"use strict";
/* 
Variable is a container (storage area) to hold data.
we use either var or let keyword to declare variables. 

*/
// declare a variable using var

// x = 6;
// console.log(x);
var firstName = "Basant";

// use a variable
console.log(firstName);

// Modify value
firstName = "Kajal";
console.log(firstName);
