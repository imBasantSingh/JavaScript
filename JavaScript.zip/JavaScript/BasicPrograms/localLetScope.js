// program showing local scope of a variable
let a = "hello";

function greet() {
  let b = "World";
  console.log(a + b);
}

greet();
console.log(a + b); // error
