/* 
	console.log() is a built-in function in JavaScript that 
	allows you to output information to the console.
*/

console.log(`Hello World`);
console.log(`Hello "World"`);
console.log("Let's Start JavaScript");
console.log("Practice code daily ! ");

/*
//ReferenceError: Basant is not defined
console.log(Basant);
*/
