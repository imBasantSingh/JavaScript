"use strict";
// The const keyword was also introduced in the ES6(ES2015) version to create constants.
// Once a constant is initialized, we cannot change its value.
// Note: If you are sure that the value of a variable won't change
// throughout the program, it's recommended to use const
const pi = 3.14;
console.log(pi);
