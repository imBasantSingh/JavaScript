/*
JavaScript is a dynamically typed (loosely typed) language.
JavaScript automatically determines the variables' data type for you.

It also means that a variable can be of one data type and later 
it can be changed to another data type.
*/

// data is of undefined type
let data;

// data is of integer type
data = 5;

// data is of string type
data = "https://www.programiz.com/";
console.log(data);

//number to string
let result = String(324);
console.log(result); // "324"
console.log(typeof result);

//string to number
result = Number(result);
console.log(result); // 324
console.log(typeof result);

/*
Implicit Conversion to String
When a number is added to a string, JavaScript converts the number to a string before concatenation.
*/
// numeric string used with + gives string type
let NumtoStringImplicit;

NumtoStringImplicit = "3" + 2;
console.log(NumtoStringImplicit); // "32"

NumtoStringImplicit = "3" + true;
console.log(NumtoStringImplicit); // "3true"

NumtoStringImplicit = "3" + undefined;
console.log(NumtoStringImplicit); // "3undefined"

NumtoStringImplicit = "3" + null;
console.log(NumtoStringImplicit); // "3null"

/*
Implicit Conversion to Number
numeric string used with - , / , * results number type

*/

let StringtoNumImplicit;

StringtoNumImplicit = "4" - "2";
console.log(StringtoNumImplicit); // 2

StringtoNumImplicit = "4" - 2;
console.log(StringtoNumImplicit); // 2

StringtoNumImplicit = "4" * 2;
console.log(StringtoNumImplicit); // 8

StringtoNumImplicit = "4" / 2;
console.log(StringtoNumImplicit); // 2
