// String indexing

let firstName = "BasantSingh";

//  B  a  s  a  n  t   S  i  n  g  h
//  0  1  2  3  4  5   6  7  8  9  10

console.log(firstName[0]);
// length of string
// firstName.length

console.log(firstName.length);

console.log(firstName[firstName.length - 3]);

// last Index : length - 1
