// trim()
// toUpperCase()
// toLowerCase()
// slice()

let firstName = "     Basantkajal      ";

console.log(firstName.length);
firstName = firstName.trim(); // "Basantkajal"
console.log(firstName);
// console.log(firstName.length);
// firstName = firstName.toUpperCase();
// firstName = firstName.toLowerCase();
// console.log(firstName);

// start index
// end index

let newString = firstName.slice(0, 8);
console.log(newString);
