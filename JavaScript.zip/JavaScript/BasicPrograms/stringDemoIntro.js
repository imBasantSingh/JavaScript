/* 
string is a primitive data type that is used to work with texts.

*/

let string1 = "17";
let string2 = "10";

//Convert string to number
let newString = +string1 + +string2;

console.log(newString); //27
console.log(typeof newString); //number

// string concatenation
let newString2 = string1 + string2;

console.log(newString2); //1710
console.log(typeof newString2); //string

console.log(
  "String with \n\
multiple \n\
lines"
);

console.log(`String
multiple
lines`);
