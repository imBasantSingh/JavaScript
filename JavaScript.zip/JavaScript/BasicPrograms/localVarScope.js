// program showing local scope of a variable
var a = "hello";

function greet() {
  var b = "World";
  console.log(a + b);
}

greet();
console.log(a + b); // error
