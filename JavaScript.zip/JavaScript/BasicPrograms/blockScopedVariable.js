// program showing block-scoped concept
// global variable

let a = "Basant";

function sayHelloBasant() {
  //local variable
  let b = "Kumar";

  console.log(a + "" + b);

  if (b == "Kumar") {
    //block-scoped variable
    let c = "Singh";

    console.log(a + " " + b + " " + c);
  }

  //variable c cannot be accessed here
  console.log(a + " " + b + " " + c);
}

sayHelloBasant();
