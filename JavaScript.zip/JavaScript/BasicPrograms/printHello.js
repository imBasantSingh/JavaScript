/* 
	console.log() is a built-in function in JavaScript that allows you to output information to the console.
	The alert() method displays an alert box over the current window with the specified message.
	document.write() is used when you want to print the content to the HTML document.
*/

console.log(`Hello World`);
alert(`Hello "World"`);
document.write("Let's Start JavaScript");
document.writeln();
document.writeln("Practice code daily ! ");

/*
//ReferenceError: Basant is not defined
console.log(Basant);
*/
