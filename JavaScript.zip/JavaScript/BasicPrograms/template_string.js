// template string
let age = 32;
let firstName = "Basant kumar singh";

let aboutMe = `My name is ${firstName} , My age is ${age}`;
console.log(`string text line 1
string text line 2`);
// "string text line 1
// string text line 2"

console.log(aboutMe);
