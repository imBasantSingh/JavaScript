"use strict";

// This data type was introduced in a newer version of JavaScript (from ES2015).

// A value having the data type Symbol can be referred to as a symbol value.
// Symbol is an immutable primitive value that is unique.

// two symbols with the same description

const value1 = Symbol("hello");
const value2 = Symbol("hello");

//Though value1 and value2 both contain 'hello', they are different as they are of the Symbol type.
