// Rules for naming variables
// you cannot start with number
// example
// var 1value = 2;  // invalid
// var value1 = 2;  // valid

var value1 = 2;
console.log(value1);

// you can use only undersore(_) or dollar($) symbol
// let $first_name = "Basant";  // valid
let _firstname = "Basant"; // valid
console.log(_firstname);

// let first$name = "Kajal"; // valid
let $firstname = "Kajal"; // valid
console.log($firstname);

// you cannot use spaces
// var first_name = "Varsha"; // snake case writing
// var firstName = "Varsha"; // camel case writing
// first name     // invalid

// convention
// start with small letter and use camelCase
// JavaScript is case-sensitive. So y and Y are different variables.
// Keywords cannot be used as variable names.
/*
Though you can name variables in any way you want, it's a good practice 
to give a descriptive variable name. If you are using a variable to store 
the number of apples, it better to use apples or numberOfApples rather than x or n.

In JavaScript, the variable names are generally written in camelCase if 
it has multiple words. For example, firstName, annualSalary, etc.
*/
