// typeof operator

// 1. Number: Floating point numbers. Used for decimals and integers
// 2. String: Sequence of characters. Used for text
// 3. Boolean: Logical type that can only be true or false. Used for taking decisions
// 4. Undefined: Value taken by a variable that is not yet defined (‘empty value’)
// 5. Null: Also means ‘empty value’
// 6. Symbol (ES2015): Value that is unique and cannot be changed [Not useful for now]
// 7. BigInt (ES2020): Larger integers than the Number type can hold

let age = 32;
let firstName = "Basant";
console.log(typeof age);
console.log(typeof firstName);

// 22 -> "22"
// convert number to string.
age = age + "";
console.log(typeof age);

//convert string to number.

let myStr = +"34";
console.log(typeof myStr);

age = "18";
age = Number(age);
console.log(typeof age);

/*
JavaScript is a dynamically typed (loosely typed) language.
JavaScript automatically determines the variables' data type for you.

It also means that a variable can be of one data type and later 
it can be changed to another data type.
*/
// data is of undefined type
let data;

// data is of integer type
data = 5;

// data is of string type
data = "https://www.programiz.com/";
console.log(data);
