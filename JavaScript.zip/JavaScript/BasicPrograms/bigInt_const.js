"use strict";

/*
In JavaScript, Number type can only represent numbers less than (2^53 - 1) and more than -(2^53 - 1). 
However, if you need to use a larger number than that, you can use the BigInt data type.

A BigInt number is created by appending n to the end of an integer.

*/
// Initializing BigInt value
const value1 = 900719925124740998n;

// Adding two big integers
const result1 = value1 + 1n;
console.log(result1); // "900719925124740999n"

const value2 = 900719925124740998n;

// Error! BitInt and number cannot be added
//const result2 = value2 + 1;
//console.log(result2);
