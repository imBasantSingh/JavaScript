"use strict";

let a = 5;
let b = 7;

a += 5; //a = 10
console.log(`Value of a = ${a}`);
//console.log(`Value of b = ${b}`);

a -= 2; //a = 8
console.log(`Value of a = ${a}`);

b *= 3; // b = 21
console.log(`Value of b = ${b}`);

a /= 2; // a = 4
console.log(`Value of a = ${a}`);

b %= 2; // b = 1
console.log(`Value of b = ${b}`);

a **= 2; // a = 16
console.log(`Value of a = ${a}`);
