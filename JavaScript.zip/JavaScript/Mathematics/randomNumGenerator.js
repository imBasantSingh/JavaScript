// The Math.random() function returns a floating-point,
// pseudo-random number between 0 (inclusive) and 1 (exclusive).
let randomNum = Math.random();

//console.log(randomNumber);

/*
 Random number between 1 and 6
*/

let diceNumber = Math.trunc(Math.random() * 6) + 1;
// console.log(diceNumber);

/*
Random number between two numbers
*/

let randomNumberGenerator = function (min, max) {
  let randomNumber = Math.trunc(Math.random() * max) + min;
  // console.log(randomNumber);
  return randomNumber;
};

console.log(randomNumberGenerator(1, 100));
