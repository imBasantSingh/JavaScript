"use strict";
const number1 = 20;
const number2 = 2;

let addNum = number1 + number2;
let subNum = number1 - number2;
let multiply = number1 * number2;
let reminder = number1 % number2;
let power = number1 ** number2;

console.log(`${number1} + ${number2} = ${addNum}`);
console.log(`${number1} - ${number2} = ${subNum}`);
console.log(`${number1} * ${number2} = ${multiply}`);
console.log(`${number1} % ${number2} = ${reminder}`);
console.log(`${number1} ** ${number2} = ${power}`);
console.log(" ");
console.log("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
console.log(" ");

// Multiplication table
let multiplication = 1;
for (let i = 1; i <= 10; i += 2) {
  multiplication = i * number1;
  console.log(`${i} * ${number1} = ${multiplication}`);
}
