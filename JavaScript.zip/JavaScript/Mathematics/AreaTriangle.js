const base = 4;
const height = 7;
let areaTriangle = 0;

areaTriangle = 0.5 * base * height;

console.log(`Area of triangle is ${areaTriangle}`);
