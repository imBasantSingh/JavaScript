const num1 = 2.25;
const num2 = -4;
const num3 = "4";
const num4 = 4;
const demoString = "hello";

const result1 = Math.sqrt(num1);
const result2 = Math.sqrt(num2);
const result3 = Math.sqrt(num3);
const result4 = Math.sqrt(num4);
const result5 = Math.sqrt(demoString);

console.log(`The square root of ${num1} is ${result1}`);
console.log(`The square root of ${num2} is ${result2}`);
console.log(`The square root of ${num3} is ${result3}`);
console.log(`The square root of ${num4} is ${result4}`);
console.log(`The square root of ${demoString} is ${result5}`);
