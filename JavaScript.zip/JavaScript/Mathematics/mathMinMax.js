/* 
The Math.min() static method returns the smallest of the numbers given
 as input parameters, or Infinity if there are no parameters.

 The Math.max() static method returns the largest of the numbers given 
 as input parameters, or -Infinity if there are no parameters.
 */

// console.log(Math.min(2, 3, 1));
// // Expected output: 1

// console.log(Math.min(-2, -3, -1));
// // Expected output: -3

// console.log(Math.max(1, 3, 2));
// // Expected output: 3

// console.log(Math.max(-1, -3, -2));
// // Expected output: -1

const array1 = [2, 3, 1, 5, 7, 9, 11, 17, 20, 22, 34, -32, 45];

let Min = Math.min(...array1);
console.log(`Minimum number is ${Min}`);

let Max = Math.max(...array1);
console.log(`Maximum number is ${Max}`);
