"use strict";

const onClickFunc = function () {
  document.getElementById("datetime").onclick = document.getElementById(
    "datetime"
  ).innerHTML = Date();
};
