// array shift unshift 
let fruits = ["apple", "mango", "grapes"];
console.log(fruits);

// unshift 
fruits.unshift("banana");
fruits.unshift("guava");
console.log(fruits);

// shift 
let removedFruit = fruits.shift();
console.log(fruits);
console.log("Removed fruits is ", removedFruit);