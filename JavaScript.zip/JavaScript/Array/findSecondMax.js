"use strict";

let calcSecondMax = (array) => {
  let max = array[0];
  let secondMax = array[0];
  for (let i = 0; i < array.length; i++) {
    if (array[i] > max) {
      secondMax = max;
      max = array[i];
    } else if (array[i] > secondMax && array[i] < max) {
      secondMax = array[i];
    }
  }
  return secondMax;
};

const arrayNumbers = [
  10, 5, 20, 8, 15, -22, 23, 45, 61, 82, 4, 3, -32, -20, 91, 102, 112,
];

console.log(calcSecondMax(arrayNumbers));
