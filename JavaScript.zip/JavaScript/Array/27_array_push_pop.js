// array push pop 

let fruits = ["apple", "mango", "grapes"];
console.log(fruits);

// push 
fruits.push("banana");
console.log(fruits);

// pop 
let poppedFruit = fruits.pop();
console.log(fruits);
console.log("popped fruits is", poppedFruit);