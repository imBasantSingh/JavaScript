function wishHappyBirthday() {
  console.log("Happy birthday to you ......");
}

function sayHello(name) {
  console.log(`Hello `, name);
}

function sumThreeNumbers(number1, number2, number3) {
  return number1 + number2 + number3;
}

sayHello("Basant");
wishHappyBirthday();

const sumOfThreeNumber = sumThreeNumbers(2, 4.5, 3.5);
console.log(sumOfThreeNumber);

//Calculate if number isEven
// input : 1 number
// output : true , false

function isEven(number) {
  return number % 2 === 0;
}

console.log(isEven(31));

// function
// input : string
// output: firstCharacter

// function firstChar(anyString){
//     return anyString[0];
// }

// console.log(firstChar("zbc"));
