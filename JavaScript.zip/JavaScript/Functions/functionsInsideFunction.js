// functions inside function
function app() {
  const sayHello = () => {
    console.log("hello from sayHello");
  };

  const addTwo = (num1, num2) => {
    return num1 + num2;
  };

  const mul = (num1, num2) => num1 * num2;

  console.log("Inside App");
  sayHello();
  console.log(addTwo(2, 3));
  console.log(mul(2, 3));
}
app();
