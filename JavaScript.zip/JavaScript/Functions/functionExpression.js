// function expression

const singHappyBirthday = function () {
  console.log("Happy birthday to you ......");
};

singHappyBirthday();

const sumThreeNumbers = function (number1, number2, number3) {
  return number1 + number2 + number3;
};
const ans = sumThreeNumbers(2, 3, 4);
console.log(ans);

const isEven = function (number) {
  return number % 2 === 0;
};
console.log(isEven(2));

const firstChar = function (anyString) {
  return anyString[0];
};
