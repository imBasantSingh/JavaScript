// function
// input : array, target (number)
// output: index of target if target present in array

function findNumberInArray(array, number) {
  for (var i = 0; i < array.length; i++) {
    if (number === array[i]) {
      return i;
    }
  }
  return -1;
}

const arrayNumbers = [2, 5, 7, 19, 23, 41, 80, 102, 65, 66, 67];
let num = 80;
const position = findNumberInArray(arrayNumbers, num);
if (position < 0) {
  console.log(`Number not found `);
} else console.log(`Number found at position ${position + 1}`);

const findTarget = function (array, target) {
  for (let i = 0; i < array.length; i++) {
    if (array[i] === target) {
      return i;
    }
  }
  return -1;
};

let index = findTarget([23, 45, 7, 89, 9, 11, 43, 65, 67, 68, 69, 70], 67);
console.log("Number found at " + (index + 1) + " Position");

const findTargetArrow = (array, target) => {
  for (let i = 0; i < array.length; i++) {
    if (array[i] === target) {
      return i;
    }
  }
  return -1;
};

let indexArrow = findTargetArrow(
  [23, 45, 7, 89, 9, 11, 43, 65, 67, 68, 69, 70],
  67
);
console.log("Number found at Position number " + (indexArrow + 1));
