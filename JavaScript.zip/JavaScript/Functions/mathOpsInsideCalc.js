// functions inside function
function Calc() {
  const add = (num1, num2) => num1 + num2;
  const subs = (num1, num2) => num1 - num2;
  const mul = (num1, num2) => num1 * num2;
  const rem = (num1, num2) => num1 % num2;

  console.log(`Calling function inside function`);
  console.log(add(num1, num2));
  console.log(subs(num1, num2));
  console.log(mul(num1, num2));
  console.log(rem(num1, num2));
}

const num1 = 14;
const num2 = 3;

Calc();
