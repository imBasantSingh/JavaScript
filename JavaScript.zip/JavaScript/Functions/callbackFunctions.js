// Callback functions 

function callback(name){
    console.log("Inside my func 2");
    console.log(`your name is ${name}`);
}

function myFunc(callback){
    console.log("Hello there I am a func and I can....")
    callback("Basant");
}

myFunc(callback);