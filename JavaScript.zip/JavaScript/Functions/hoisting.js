// hoisting
/*
Hoisting is a JavaScript mechanism where variable and function declarations are moved to the top of their containing scope during the compilation phase, before the code is executed.
However, it's important to note that only the declarations are hoisted, not the initializations. The variables are hoisted with an initial value of undefined.

*/

hello();

function hello() {
  console.log("hello world");
}

// console.log(hello);
// const hello = "hello world";
// console.log(hello);
